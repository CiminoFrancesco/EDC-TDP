//l'oggetto exports permette di trasmettere ed esportare 
//ad un altro script dei dati attraverso la proprietà 
//fraseDelGiorno che viene impostata con una frase scelta 
//in modo casuale all'interno di un vettore di frasi
//Per utilizzare il modulo che ho creato devo impostare nello script che lo utilizza
//il suo riferimento ad una variabile: const miomodulo=require('./fraseDelGiorno.js')
//se la frase invece di essere random fosse fissa il modulo sarebbe fatto in questo modo:
//exports.fraseDelGiorno='Che cosa hanno in comune un televisore e una formica? Le antenne!';
//tutte le funzioni non esportate nello script del modulo rimarranno private
//possono pertanto essere utilizzate da altre funzioni
//del modulo
regioni = {
    "regions": [
      {
        "name": "Campania",
        "number": 53.21,
        "coordinates": {
          "latitude": 40.8396,
          "longitude": 14.2508
        }
      },
      {
        "name": "Calabria",
        "number": 41.76,
        "coordinates": {
          "latitude": 38.9055,
          "longitude": 16.5942
        }
      },
      {
        "name": "Sicilia",
        "number": 31.80,
        "coordinates": {
          "latitude": 37.599993,
          "longitude": 14.015356
        }
      },
      {
        "name": "Puglia",
        "number": 24.34,
        "coordinates": {
          "latitude": 41.1256,
          "longitude": 16.8669
        }
      },
      {
        "name": "Lazio",
        "number": 23.83,
        "coordinates": {
          "latitude": 41.9028,
          "longitude": 12.4964
        }
      },
      {
        "name": "Piemonte",
        "number": 22.44,
        "coordinates": {
          "latitude": 45.0703,
          "longitude": 7.6869
        }
      },
      {
        "name": "Liguria",
        "number": 10.11,
        "coordinates": {
          "latitude": 44.4056,
          "longitude": 8.9463
        }
      },
      {
        "name": "Basilicata",
        "number": 5.32,
        "coordinates": {
          "latitude": 40.6438,
          "longitude": 15.9695
        }
      },
      {
        "name": "Lombardia",
        "number": 4.17,
        "coordinates": {
          "latitude": 45.4668,
          "longitude": 9.1905
        }
      },
      {
        "name": "Toscana",
        "number": 2.16,
        "coordinates": {
          "latitude": 43.7711,
          "longitude": 11.2486
        }
      },
      {
        "name": "Umbria",
        "number": 1.68,
        "coordinates": {
          "latitude": 42.9384,
          "longitude": 12.6216
        }
      },
      {
        "name": "Emilia Romagna",
        "number": 1.44,
        "coordinates": {
          "latitude": 44.4949,
          "longitude": 11.3426
        }
      },
      {
        "name": "Abruzzo",
        "number": 0.74,
        "coordinates": {
          "latitude": 42.3512,
          "longitude": 13.3986
        }
      },
      {
        "name": "Sardegna",
        "number": 0.70,
        "coordinates": {
          "latitude": 39.2153,
          "longitude": 9.1217
        }
      },
      {
        "name": "Marche",
        "number": 0.67,
        "coordinates": {
          "latitude": 43.6167,
          "longitude": 13.5167
        }
      },
      {
        "name": "Valle D'Aosta",
        "number": 0.57,
        "coordinates": {
          "latitude": 45.7389,
          "longitude": 7.3150
        }
      },
      {
        "name": "Friuli Venezia Giulia",
        "number": 0.42,
        "coordinates": {
          "latitude": 45.6495,
          "longitude": 13.7768
        }
      },
      {
        "name": "Veneto",
        "number": 0.41,
        "coordinates": {
          "latitude": 45.4342,
          "longitude": 12.3387
        }
      },
      {
        "name": "Trentino Alto Adige",
        "number": 0.37,
        "coordinates": {
          "latitude": 46.0682,
          "longitude": 11.1212
        }
      },
      {
        "name": "Molise",
        "number": 0.31,
        "coordinates": {
          "latitude": 41.6667,
          "longitude": 14.6667
        }
      }
    ]
  }
exports.regioni=function () {
	return {
		regions: regioni["regions"]
	};
}