// Dipendenze del progetto
const express=require('express');//importo il framework Express
const app=express();
const fs = require('fs'); //importo il modulo per la gestione del File System
const morgan=require('morgan');  //importo il modulo per la gestione dei logger
const path = require('path'); //importo il modulo per la gestione dei percorsi delle cartelle e dei file
const helmet=require('helmet'); //importo il modulo per rendere il server web piu sicuro
const mymodule=require('./moduli/regions');
const cors=require('cors');// Cors (Cross origin resource sharing, protocollo che permette il passaggio di dati tra applicazioni e domini diversi)
const bodyParser = require('body-parser');//Per leggere i parametri POST occorre preventivamente installare il modulo body-parser

//Sezione impostazione dell’app (app.set)app.set ('port',process.env.PORT || 3000); //imposta la porta in cui è in ascolto il server
app.set ('appName', 'Web Service'); //imposta il nome dell'applicazione web
app.set ('port',process.env.PORT || 3000); //imposta la porta in cui è in ascolto il server

//Sezione Middleweare
//Middleweare Morgan: per la creazione di un logger: formati predefiniti (short, combined, common, tiny)
//oppure app.use(morgan(':method :url :status - :response-time ms', {stream: accessLogStream}));
const accessLogStream = fs.createWriteStream(path.join(__dirname, 'access.log'), {flags: 'a'});
app.use(morgan('short', {stream: accessLogStream}));
//Middleweare sicurezza helmet
app.use(helmet());

app.use(cors());


let users =[];


//La lettura dei parametri della richiesta può poi essere eseguita attraverso le seguenti routes middleware che 
//restituiscono i parametri stessi in formato json all’interno di req.body
//Il primo middleware intercetta i parametri url-encoded.
//Il secondo middleware intercetta i parametri scritti in formato json serializzato, restituendoli nella medesima 
//property request.body
//L’opzione extended:false consente di passare come parametri stringhe, vettori e anche oggetti json 
//semplici codificati come object
//L’opzione extended:true consente anche l’utilizzo di oggetti estesi (json object annidati)
//Il default è true, però se si omette l’opzione extended il compilatore segnala un warning piuttosto fastidioso.

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());



//Sezione Route
//La Route che segue viene eseguita quando arriva una richiesta get del 
//client sulla risorsa /frase del giorno, il server  in questo caso spedisce al 
//client una frase	

app.get('/regions',function(req,res){
	console.log("passato");
	res.status(200);
	res.json(mymodule.regioni());
});

//Middleweare che gestisce l’errore nel caso che nessuna route vada a buon fine
app.use("*",function (req,res,next){	
	res.status(404);
	res.send('Url non presente');
});

//Avvio del server su una porta specifica
const server=app.listen(app.get('port'),function(){
    console.log('Server in ascolto');
});

