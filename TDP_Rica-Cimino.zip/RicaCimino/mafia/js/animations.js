//per animazioni
const muovi = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
            console.log(entry);
            if (entry.isIntersecting) {

                entry.target.classList.add('mostra');
                observer.unobserve(entry.target); // Stop observing once animation is complete
            }
        });
    });

    const nascosti = document.querySelectorAll('.nascosto');
    nascosti.forEach((element) => muovi.observe(element));