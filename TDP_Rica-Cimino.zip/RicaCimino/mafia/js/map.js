
var map = L.map('map').setView([41.8719, 12.5674], 6); // Imposta la vista sulla posizione centrale dell'Italia con un livello di zoom iniziale di 6

    // Aggiungi uno strato di mappa di base da OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Funzione per aggiungere i marker delle regioni sulla mappa
    function addMarkers(regions) {
        regions.forEach(function(region, index) {
            // Crea un marker con le coordinate della regione
            var marker = L.marker([region.coordinates.latitude, region.coordinates.longitude]).addTo(map);
            // Aggiungi un popup al marker con il nome della regione e la densità mafiosa
            marker.bindPopup("<b>" + (index + 1) + ". " + region.name + "</b><br>Densità Mafiosa: " + region.number);
        });
    }

    // Funzione per aggiungere i cerchi delle regioni sulla mappa
    function addCircles(regions) {
        regions.forEach(function(region, index) {
            // Crea un cerchio con le coordinate della regione e il raggio proporzionale alla densità mafiosa
            L.circle([region.coordinates.latitude, region.coordinates.longitude], {
                color: 'red',
                fillColor: '#f03',
                fillOpacity: 0.5,
                radius: Math.sqrt(region.number) * 10000 // Moltiplica per un fattore per rendere più visibili i cerchi sulla mappa
            }).addTo(map).bindPopup("<b>" + (index + 1) + ". " + region.name + "</b><br>Densità Mafiosa: " + region.number);
        });
    }

    // Carica il file JSON delle regioni con la densità mafiosa (Web service)
    fetch('http://127.0.0.1:3000/regions')
        .then(response => response.json())
        .then(data => {
            addMarkers(data.regions); // Aggiungi i marker
            addCircles(data.regions); // Aggiungi i cerchi
        })
        .catch(error => console.error('Errore durante il caricamento del file JSON:', error));
